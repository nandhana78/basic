from django.shortcuts import render
from django.http import HttpResponse
def war(request):
    return HttpResponse("hello world")
def home_page(request):
    return render(request,'homepage.html')
def about(request):
    return render(request, 'about.html')
