from django.contrib import admin
from django.urls import path,include
from .import views


urlpatterns = [
    path('worldwar/',views.war,name='worldwar'),
    path('',views.home_page,name='index'),
    path('about',views.about,name='page')
]
